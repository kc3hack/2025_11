package com.example.kc3_2025;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView cityCodeText, ThrowScore, rank1, rank2, rank3, rank4, rank5;
    private String selectedCategory, prefecture, city;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("Test case", "onCreate started");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TextViewのビューを取得
        cityCodeText = findViewById(R.id.city_name);
        ThrowScore = findViewById(R.id.score);
        rank1 = findViewById(R.id.rank_1);
        rank2 = findViewById(R.id.rank_2);
        rank3 = findViewById(R.id.rank_3);
        rank4 = findViewById(R.id.rank_4);
        rank5 = findViewById(R.id.rank_5);

        // "Activity_select" からの結果を受け取る
        Intent intent = getIntent();
        selectedCategory = intent.getStringExtra("selectedCategory");
        prefecture = intent.getStringExtra("prefecture");
        city = intent.getStringExtra("city");

        Log.d("MainActivity", "Received: " + selectedCategory + ", " + prefecture + ", " + city);

        // 都道府県・市区町村を表示
        if (prefecture != null && city != null) {
            cityCodeText.setText("命中地点:" + prefecture + " " + city);
        } else {
            cityCodeText.setText("場所情報が受け取れませんでした");
        }

        // CSVファイルから面積データをロード
        ScoreCalculator.loadAreaData(this);

        searchTouristSpots(prefecture, city, selectedCategory);  // 初回の観光スポットを検索

        // カテゴリー変更ボタンの設定
        Button changeCategoryButton = findViewById(R.id.change_category);
        changeCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // カテゴリー変更ボタンが押されたら、再度観光スポット検索を実行
                if(selectedCategory == "kankou"){
                    selectedCategory = "gourmet";
                }else{
                    selectedCategory = "kankou";
                }
                searchTouristSpots(prefecture, city, selectedCategory);
            }
        });
    }

    private void searchTouristSpots(String prefecture, String city, String selectedCategory) {
        if (prefecture.isEmpty() || city.isEmpty()) {
            cityCodeText.setText("都道府県名と市区町村名を入力してください");
            return;
        }

        PrefectureCode codeFinder = new PrefectureCode();
        String cityCode = codeFinder.getCityCode(prefecture, city);
        if (cityCode == null) {
            cityCodeText.setText("市区町村コードが見つかりませんでした");
            return;
        }

        // ThrowScoreの計算と表示
        double score = ScoreCalculator.calculateThrowScore(cityCode);
        ThrowScore.setText("得点：" + String.valueOf(score));

        // 観光スポットの検索を実行
        ScrapingTest scrapingTest = new ScrapingTest();
        scrapingTest.fetchTouristSpots(cityCode, selectedCategory, new ScrapingTest.FetchCallback() {
            @Override
            public void onSuccess(String[] topSpots) {
                runOnUiThread(() -> {
                    rank1.setText(topSpots.length > 0 ? topSpots[0] : "1. なし");
                    rank2.setText(topSpots.length > 1 ? topSpots[1] : "2. なし");
                    rank3.setText(topSpots.length > 2 ? topSpots[2] : "3. なし");
                    rank4.setText(topSpots.length > 3 ? topSpots[3] : "4. なし");
                    rank5.setText(topSpots.length > 4 ? topSpots[4] : "5. なし");
                });
            }

            @Override
            public void onError(String errorMessage) {
                runOnUiThread(() -> cityCodeText.setText(errorMessage));
            }
        });
    }
}
